#include "HsFFI.h"
#ifdef __cplusplus
extern "C" {
#endif
extern HsInt32 hailstone_hs(HsInt32 a1);
extern HsInt32 fib_hs(HsInt32 a1);
extern HsInt32 fact_hs(HsInt32 a1);
#ifdef __cplusplus
}
#endif

